create definer = `skip-grants user`@`skip-grants host` trigger current_is_default
    after insert
    on sys_address
    for each row
begin
    declare total int;
    set total = (
        select count(id)
        from sys_address
        where a_id = NEW.a_id
    );
    if total = 1 then
        # 当前address就是默认地址，更新user的默认地址
        update sys_user
            set sys_user.default_address_id = NEW.id
        where a_id = NEW.a_id;
    end if;
end;

