create definer = `skip-grants user`@`skip-grants host` trigger update_order_status_insert_bk
    after update
    on sys_order
    for each row
begin
    if NEW.order_payment_status = 1 then
        insert into sys_order_success(serial_number, book_id, username_id, order_content, product_count, whole_price,
                                 obtain_score, create_time, payment_time, delivery_time, end_time, order_payment_status,
                                 use_score, book_name)
        values (NEW.serial_number, NEW.book_id, NEW.username_id, NEW.order_content, NEW.product_count, NEW.whole_price,
                NEW.obtain_score, NEW.create_time, NEW.payment_time, NEW.delivery_time, NEW.end_time,
                NEW.order_payment_status, NEW.use_score, NEW.book_name);
    end if;
end;

